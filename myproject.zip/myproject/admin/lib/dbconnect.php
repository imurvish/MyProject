<?php
class dbconnect
{
    function connect()
    {
        $connection=mysqli_connect("localhost","root","","admin_db");
				return $connection;
    }
}
?>