<?php 
session_start();
date_default_timezone_set('Asia/Calcutta');
include 'common/checkLogin.php';
include 'common/object.php';
$user_id= $_SESSION['user_id'];
$created_by=$_SESSION['name'];
$updated_by=$_SESSION['name'];

// Developed By parth ka patel

if(isset($_POST) && !empty($_POST) )//it can be $_GET doesn't matter
{
	extract(array_map("test_input" , $_POST));
	// add main menu
	if(isset($_POST['menu_name'])){
		$m->set_data('menu_name',$menu_name);
	    $m->set_data('menu_link',$menu_link);
	  	$m->set_data('menu_icon',$menu_icon);
	  	$m->set_data('sub_menu',$sub_menu);
	  	$m->set_data('status',$status);
	  	$m->set_data('order_no',$order_no);
	  	$m->set_data('created_by',$created_by);

	  	$a =array(
	  		'menu_name'=> $m->get_data('menu_name'),
      		'menu_link'=> $m->get_data('menu_link'),
      		'menu_icon'=>$m->get_data('menu_icon'),
      		'sub_menu'=>$m->get_data('sub_menu'),
      		'status'=>$m->get_data('status'),
      		'order_no'=>$m->get_data('order_no'),
      		'created_by'=>$m->get_data('created_by'),
	  	);
	  	$q=$d->insert("master_menu",$a);
	  	if($q>0) {
	  		$_SESSION['msg']="New menu successfully  added.";
	  		header("location:mainMenu.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:menu.php");
	  	}
	}

	// Edit main menu
	if(isset($_POST['menu_nameEdit'])){
		$m->set_data('menu_nameEdit',$menu_nameEdit);
	    $m->set_data('menu_link',$menu_link);
	  	$m->set_data('menu_icon',$menu_icon);
	  	$m->set_data('sub_menu',$sub_menu);
	  	$m->set_data('status',$status);
	  	$m->set_data('order_no',$order_no);
	  	$m->set_data('updated_by',$updated_by);

	  	$a =array(
	  		'menu_name'=> $m->get_data('menu_nameEdit'),
      		'menu_link'=> $m->get_data('menu_link'),
      		'menu_icon'=>$m->get_data('menu_icon'),
      		'sub_menu'=>$m->get_data('sub_menu'),
      		'status'=>$m->get_data('status'),
      		'order_no'=>$m->get_data('order_no'),
      		'updated_by'=>$m->get_data('updated_by'),
	  	);
	  	$q=$d->update("master_menu",$a,"menu_id='$menu_id'");
	  	if($q>0) {
	  		$_SESSION['msg']=" Menu Successfully  Updated.";
	  		header("location:mainMenu.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:menu.php");
	  	}
	}
	// add sub menu
	if(isset($_POST['sub_menu_name'])){
		$m->set_data('menu_id',$menu_id);
		$m->set_data('sub_menu_name',$sub_menu_name);
	    $m->set_data('sub_menu_link',$sub_menu_link);
	  	$m->set_data('status',$status);
	  	$m->set_data('created_by',$created_by);

	  	$a =array(
	  		'menu_id'=> $m->get_data('menu_id'),
	  		'sub_menu_name'=> $m->get_data('sub_menu_name'),
      		'sub_menu_link'=> $m->get_data('sub_menu_link'),
      		'status'=>$m->get_data('status'),
      		'created_by'=>$m->get_data('created_by'),
	  	);
	  	$q=$d->insert("sub_menu",$a);
	  	if($q>0) {
	  		$_SESSION['msg']="New menu successfully  added.";
	  		header("location:subMenu.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:addSubMenu.php");
	  	}
	}

	// Edit sub menu
	if(isset($_POST['sub_menu_nameEdit'])){
		$m->set_data('menu_id',$menu_id);
		$m->set_data('sub_menu_nameEdit',$sub_menu_nameEdit);
	    $m->set_data('sub_menu_link',$sub_menu_link);
	  	$m->set_data('status',$status);
	  	$m->set_data('updated_by',$updated_by);

	  	$a =array(
	  		'menu_id'=> $m->get_data('menu_id'),
	  		'sub_menu_name'=> $m->get_data('sub_menu_nameEdit'),
      		'sub_menu_link'=> $m->get_data('sub_menu_link'),
      		'status'=>$m->get_data('status'),
      		'updated_by'=>$m->get_data('updated_by'),
	  	);
	  	$q=$d->update("sub_menu",$a,"sub_menu_id='$sub_menu_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="Sub Menu Updated.";
	  		header("location:subMenu.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:addSubMenu.php");
	  	}
	}
	// add new icon

	if(isset($_POST['icon_name'])){
		$m->set_data('icon_name',$icon_name);
		$m->set_data('icon_class',$icon_class);
	  	$m->set_data('status',$status);
	  	$m->set_data('created_by',$created_by);

	  	$a =array(
	  		'icon_name'=> $m->get_data('icon_name'),
	  		'icon_class'=> $m->get_data('icon_class'),
      		'status'=>$m->get_data('status'),
      		'created_by'=>$m->get_data('created_by'),
	  	);
	  	$q=$d->insert("icons",$a);
	  	if($q>0) {
	  		$_SESSION['msg']="New Icon successfully  added.";
	  		header("location:icons.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:icons.php");
	  	}
	}

	// delete Icon

	if(isset($_POST['deleteIcon'])) {
		$q=$d->delete("icons","icon_id='$icon_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="Icon Deleted  successfully.";
	  		header("location:icons.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:icons.php");
	  	}
	}

	// delete Main Menu

	if(isset($_POST['deleteMenu'])) {
		$q=$d->delete("master_menu","menu_id='$menu_id'");
	  	if($q>0) {
			$q1=$d->delete("sub_menu","menu_id='$menu_id'");
	  		$_SESSION['msg']="Menu Deleted  successfully.";
	  		header("location:mainMenu.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:mainMenu.php");
	  	}
	}

	// delete Sub Main Menu

	if(isset($_POST['deleteSubMenu'])) {
		$q=$d->delete("sub_menu","sub_menu_id='$sub_menu_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="Sub Menu Deleted  successfully.";
	  		header("location:subMenu.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:subMenu.php");
	  	}
	}

	// change Password
	if(isset($_POST["oldPassword"]))
	{
	    extract(array_map("test_input" , $_POST));

	    $q=$d->select("users_master","user_id='$user_id'");
	    $data=mysqli_fetch_array($q);
	    $old= $data['password'];
	    $mobile= $data['mobile'];
	    $Password2=md5($Password2);
	    $oldPassword=md5($oldPassword);
	    if($old==$oldPassword) {
	        if($Password2==$Password2) {
	            $m->set_data('Password2',$Password2);
	            $a1= array ('password'=> $m->get_data('Password2')
	            );

	            $update=$d->update("users_master",$a1 ,"user_id='$user_id'");

	            if($update>0)
	            {
	            
	                $_SESSION['msg']="New Password Set Successfully.";
	                header('location:index.php');
	            }
	            else {
	                $_SESSION['msg1']="Something Wrong.";
	                header('location:index.php');

	            }
	        } else {
	            $_SESSION['msg1']="Confirm password does not match Try Again !";
	            header('location:changePassword.php');
	        }
	    }
	    else {
	        $_SESSION['msg1']="Old Password Is Wrong Try Again.";
	        header('location:changePassword.php');
	    }
	}  

	// Add user Role
	if(isset($_POST['role_name'])){
		$menu_id= implode(",", $_POST['menu_id']);
		$sub_menu_id= implode(",", $_POST['sub_menu_id']);
		$m->set_data('role_name',$role_name);
	    $m->set_data('role_description',$role_description);
	  	$m->set_data('status',$status);
	  	$m->set_data('order_no',$order_no);
	  	$m->set_data('menu_id',$menu_id);
	  	$m->set_data('sub_menu_id',$sub_menu_id);
	  	$m->set_data('created_by',$created_by);

	  	$a =array(
	  		'role_name'=> $m->get_data('role_name'),
      		'role_description'=> $m->get_data('role_description'),
      		'role_status'=>$m->get_data('status'),
      		'order_no'=>$m->get_data('order_no'),
      		'menu_id'=>$m->get_data('menu_id'),
      		'sub_menu_id'=>$m->get_data('sub_menu_id'),
      		'created_by'=>$m->get_data('created_by'),
	  	);
	  	$q=$d->insert("role_master",$a);
	  	if($q>0) {
	  		$_SESSION['msg']="New Role Successfully  Added.";
	  		header("location:roleType.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:roleType.php");
	  	}
	}

	// Edit user Role
	if(isset($_POST['role_nameEdit'])){
		$menu_id= implode(",", $_POST['menu_id']);
		$sub_menu_id= implode(",", $_POST['sub_menu_id']);
		$m->set_data('role_nameEdit',$role_nameEdit);
	    $m->set_data('role_description',$role_description);
	  	$m->set_data('status',$status);
	  	$m->set_data('order_no',$order_no);
	  	$m->set_data('menu_id',$menu_id);
	  	$m->set_data('sub_menu_id',$sub_menu_id);
	  	$m->set_data('updated_by',$updated_by);

	  	$a =array(
	  		'role_name'=> $m->get_data('role_nameEdit'),
      		'role_description'=> $m->get_data('role_description'),
      		'role_status'=>$m->get_data('status'),
      		'order_no'=>$m->get_data('order_no'),
      		'menu_id'=>$m->get_data('menu_id'),
      		'sub_menu_id'=>$m->get_data('sub_menu_id'),
      		'updated_by'=>$m->get_data('updated_by'),
	  	);
	  	$q=$d->update("role_master",$a,"role_id='$role_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="Role Updated Successfully  Added.";
	  		header("location:roleType.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:roleType.php");
	  	}
	}

	// Delete Role Type

	if(isset($_POST['deleteRole'])) {
		$q=$d->delete("role_master","role_id='$role_id'");
		
	  	if($q>0) {
	  		$_SESSION['msg']="Role Type Deleted  successfully.";
	  		header("location:roleType.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:roleType.php");
	  	}
	}

	// add New user 

	if(isset($_POST['first_name'])){
		$q=$d->select("users_master","email='$email'");
		$data=mysqli_fetch_array($q);
		if($data>0){
			$_SESSION['msg1']="$email  is already register.";
	  		header("location:user.php");
		} else {
		$password = md5($Password2);
		$m->set_data('role_id',$role_id);
	    $m->set_data('first_name',$first_name);
	  	$m->set_data('last_name',$last_name);
	  	$m->set_data('email',$email);
	  	$m->set_data('password',$password);
	  	$m->set_data('status',$status);
	  	//$m->set_data('profile',$profile);
	  	$m->set_data('created_by',$created_by);

	  	$a =array(
	  		'role_id'=> $m->get_data('role_id'),
      		'first_name'=> $m->get_data('first_name'),
      		'last_name'=>$m->get_data('last_name'),
      		'email'=>$m->get_data('email'),
      		'password'=>$m->get_data('password'),
      		'status'=>$m->get_data('status'),
      		//'profile'=>$m->get_data('profile'),
      		'created_by'=>$m->get_data('created_by'),
	  	);
	  	$q=$d->insert("users_master",$a);
	  	if($q>0) {
	  		if($notify=="email") {
	  			// send email for notify
				$subject = "My subject";
				$txt = "Hi $first_name,\n\n Your new account successfully created on Diwagine Portal, your username is : $email &  password is: $Password2";
				$headers = "From: support@silverwingtechnologies.com";

				mail($email,$subject,$txt,$headers);
	  		}
	  		$_SESSION['msg']="New User successfully  added.";
	  		header("location:staff.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:staff.php");
	  	}
	  }
	}

//add product category
	if(isset($_POST['addCategory'])){

		$m->set_data('category_name',$category_name);
		$m->set_data('cat_url',$cat_url);
		$m->set_data('sub_menu',$sub_menu);
		$m->set_data('category_status',$category_status);
		$m->set_data('created_by',$created_by);

		$a=array(
					'category_name'=>$m->get_data('category_name'),
					'cat_url'=>$m->get_data('cat_url'),
					'sub_menu'=>$m->get_data('sub_menu'),
					'category_status'=>$m->get_data('category_status'),
					'created_by'=>$m->get_data('created_by')
				);

		$q=$d->insert("productcategory_master",$a);

		if($q>0) {
	  		$_SESSION['msg']="New menu successfully  added.";
	  		header("location:managecategory.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:addcategory.php");
	  	}

		
	}
	//Edit product category

	if(isset($_POST['editCategoryMenu']))
	{
			$m->set_data('category_name',$category_name);
			$m->set_data('cat_url',$cat_url);
			$m->set_data('sub_menu',$sub_menu);
			$m->set_data('category_status',$category_status);
			$m->set_data('updated_by',$updated_by);
	  $a=array(

	  			'category_name'=>$m->get_data('category_name'),
	  			'cat_url'=>$m->get_data('cat_url'),
	  			'sub_menu'=>$m->get_data('sub_menu'),
	  			'category_status'=>$m->get_data('category_status'),
	  			'updated_by'=>$m->get_data('updated_by')
			  );

	  	$q=$d->update("productcategory_master",$a,"cat_id='$cat_id'");
	  	if($q>0)
	  	{
	  		$_SESSION['msg']=" Menu Successfully  Updated.";
	  		header("location:managecategory.php");
	  	}
	  	else{

	  		$_SESSION['msg1']="Something wrong";
	  		header("location:addcategory.php");
	  	}

	}
	if(isset($_POST['deleteCategoryMenu'])) {
		$q=$d->delete("productcategory_master","cat_id='$cat_id'");
	  	if($q>0) {
			$q1=$d->delete("product_subcategory_master","cat_id='$cat_id'");
	  		$_SESSION['msg']="Menu Deleted  successfully.";
	  		header("location:managecategory.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:managecategory.php");
	  	}
	}	

	//add SubCategory

	if(isset($_POST['addSubCategory'])){
		$m->set_data('cat_id',$cat_id);
		$m->set_data('subcategory_name',$subcategory_name);
	    $m->set_data('sub_url',$sub_url);
	  	$m->set_data('subcat_status',$subcat_status);
	  	$m->set_data('created_by',$created_by);

	  	$a =array(
	  		'cat_id'=> $m->get_data('cat_id'),
	  		'subcategory_name'=> $m->get_data('subcategory_name'),
      		'sub_url'=> $m->get_data('sub_url'),
      		'subcat_status'=>$m->get_data('subcat_status'),
      		'created_by'=>$m->get_data('created_by'),
	  	);
	  	$q=$d->insert("product_subcategory_master",$a);
	  	if($q>0) {
	  		$_SESSION['msg']="New menu successfully  added.";
	  		header("location:manageSubCategory.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:addSubCategory.php");
	  	}
	}

	//Edit product SubCategory
		if(isset($_POST['editSubCategory'])){
		$m->set_data('cat_id',$cat_id);
		$m->set_data('subcategory_name',$subcategory_name);
	    $m->set_data('sub_url',$sub_url);
	  	$m->set_data('subcat_status',$subcat_status);
	  	$m->set_data('updated_by',$updated_by);

	  	$a =array(
	  		'cat_id'=> $m->get_data('cat_id'),
	  		'subcategory_name'=> $m->get_data('subcategory_name'),
      		'sub_url'=> $m->get_data('sub_url'),
      		'subcat_status'=>$m->get_data('subcat_status'),
      		'updated_by'=>$m->get_data('updated_by'),
	  	);
	  	$q=$d->update("product_subcategory_master",$a,"sub_cat_id='$sub_cat_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="Sub Menu Updated.";
	  		header("location:manageSubCategory.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:addSubCategory.php");
	  	}
	}


	//delete product SubCategory
	if(isset($_POST['deleteCategoryMenu'])) {
		$q=$d->delete("product_subcategory_master","sub_cat_id='$sub_cat_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="Sub Menu Deleted  successfully.";
	  		header("location:manageSubCategory.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:manageSubCategory.php");
	  	}
	}	
	//Add Product Size

	if(isset($_POST['addSize'])){
		$m->set_data('size',$size);
	  	$m->set_data('size_active_flag',$size_active_flag);
	  	$m->set_data('create_by',$create_by);

	  	$a =array(
	  		'size'=> $m->get_data('size'),
	  		'size_active_flag'=> $m->get_data('size_active_flag'),
      		'create_by'=>$m->get_data('create_by'),
	  	);
	  	$q=$d->insert("size",$a);
	  	if($q>0) {
	  		$_SESSION['msg']="New size successfully  added.";
	  		header("location:managepsize.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:productsize.php");
	  	}
	}

	//edit Product size

	if(isset($_POST['editsize'])){
		
		$m->set_data('size',$size);
	  	$m->set_data('size_active_flag',$size_active_flag);
	  	$m->set_data('update_by',$update_by);
		
		$a =array(
	  		
	  		'size'=> $m->get_data('size'),
      		'size_active_flag'=>$m->get_data('size_active_flag'),
      		'update_by'=>$m->get_data('update_by'),
	  	);
	  	$q=$d->update("size",$a,"s_id='$s_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="product size Updated.";
	  		header("location:managepsize.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:productsize.php");
	  	}
	}
	//delete Product size 

	if(isset($_POST['deletesize'])) {
		$q=$d->delete("size","s_id='$s_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="Sub Menu Deleted  successfully.";
	  		header("location:managepsize.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:managepsize.php");
	  	}
	}	
// add Student 

	/*if(isset($_POST['addProduct'])){

	$imagetype=$_FILES["product_pic"]['type'];
	$imagesize=$_FILES["product_pic"]['size'];
	$image_Arr=$_FILES["product_pic"];

	move_uploaded_file($image_Arr['tmp_name'], 'image/'.$image_Arr['name']);
	$profile_pic=$image_Arr['name'];

	    $m->set_data('product_name',$product_name);
	  	$m->set_data('tiles_type',$tiles_type);
	  	$m->set_data('size',$size);
	  	$m->set_data('discription',$discription);
		$m->set_data('user_id',$user_id);
		$m->set_data('user_id',$user_id);
	  	$m->set_data('student_status',$student_status);
	  	$m->set_data('created_by',$created_by);



	  	$a =array(
      		'first_name'=> $m->get_data('first_name_student'),
      		'last_name'=>$m->get_data('last_name'),
      		'user_id'=>$m->get_data('user_id'),
      		'student_status'=>$m->get_data('student_status'),
      		'created_by'=>$m->get_data('created_by'),
	  	);
	  	$q=$d->insert("students_master",$a);
	  	if($q>0) {
	  		$_SESSION['msg']="New Student successfully  added.";
	  		header("location:students.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:student.php");
	  	}
	}
	// Edit Student
	if(isset($_POST['first_name_studentEdit'])){
	    $m->set_data('first_name_studentEdit',$first_name_studentEdit);
	  	$m->set_data('last_name',$last_name);
	  	$m->set_data('user_id',$user_id);
	  	$m->set_data('student_status',$student_status);
	  	$m->set_data('updated_by',$updated_by);

	  	$a =array(
      		'first_name'=> $m->get_data('first_name_studentEdit'),
      		'last_name'=>$m->get_data('last_name'),
      		'user_id'=>$m->get_data('user_id'),
      		'student_status'=>$m->get_data('student_status'),
      		'updated_by'=>$m->get_data('updated_by'),
	  	);
	  	$q=$d->update("students_master",$a,"student_id='$student_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="New Student successfully  added.";
	  		header("location:students.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:student.php");
	  	}
	}*/
	
	//add  product image

	if(isset($_POST['addproductimg'])){

		$imagetype=$_FILES["product_pic"]['type'];
		$imagesize=$_FILES["product_pic"]['size'];
		$image_Arr=$_FILES["product_pic"];

		move_uploaded_file($image_Arr['tmp_name'], 'image/'.$image_Arr['name']);
		$product_pic=$image_Arr['name'];

		$m->set_data('product_pic',$product_pic);
		$m->set_data('g_status',$g_status);
		$m->set_data('created_by',$created_by);

	  
  $a =array(
	  		
	  		 'product_pic'=> $m->get_data('product_pic'),
      		 'g_status'=> $m->get_data('g_status'),
      		 'created_by'=> $m->get_data('created_by')
			);
	  	$q=$d->insert("gallery_master",$a);
	  	if($q>0) {
	  		$_SESSION['msg']="New Picture successfully  added.";
	  		header("location:managegallery.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:gallery.php");
	  	}
	}

	//Edit  product image

    if(isset($_POST['editproductpic']))
	{

	  $file = $_FILES['product_pic']['tmp_name'];
	  if(file_exists($file)){
			 
		 $temp = explode(".", $_FILES["product_pic"]["name"]);
	     $newfilename = "USER".round(microtime(true)) . '.' . end($temp);
		 move_uploaded_file($_FILES["product_pic"]["tmp_name"], "image/" . $newfilename);
		 $product_pic=$newfilename;
	    }
	  	else
	  	{
			 $product_pic=$oldproduct;
	  	}
			  $m->set_data('product_pic',$product_pic);
	   		  $m->set_data('g_status',$g_status);
	    	  $m->set_data('updated_by',$updated_by);

	  		$a =array(
						'product_pic'=>$m->get_data('product_pic'),
      					'g_status'=>$m->get_data('g_status'),
      					'updated_by'=>$m->get_data('updated_by')
      				  );
      		
	  		$q=$d->update("gallery_master",$a,"g_id='$g_id'");
	  		if($q>0) {
	  			$_SESSION['msg']="New Image successfully  added.";
	  			header("location:managegallery.php");
	  		} else {
	  					$_SESSION['msg1']="Something wrong";
	  					header("location:managegallery.php");
	  				}
	}

	  	//delete product image
	  	if(isset($_POST['deleteproductpic'])) {
		$q=$d->delete("gallery_master","g_id='$g_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="Product Image Deleted  successfully.";
	  		header("location:managegallery.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:managegallery.php");
	  	}
	}	

	// Edit user 

	if(isset($_POST['first_nameEdit'])){
		$q=$d->select("users_master","user_id!='$user_id' AND email='$email'");
		$data=mysqli_fetch_array($q);
		if($data>0){
			$_SESSION['msg1']="$email  is already register.";
	  		header("location:users.php");
		} else {
		$password = md5($Password2);
		$m->set_data('role_id',$role_id);
	    $m->set_data('first_nameEdit',$first_nameEdit);
	  	$m->set_data('last_name',$last_name);
	  	$m->set_data('email',$email);
	  	$m->set_data('password',$password);
	  	$m->set_data('status',$status);
	  	$m->set_data('profile',$profile);
	  	$m->set_data('updated_by',$updated_by);

	  	$a =array(
	  		'role_id'=> $m->get_data('role_id'),
      		'first_name'=> $m->get_data('first_nameEdit'),
      		'last_name'=>$m->get_data('last_name'),
      		'email'=>$m->get_data('email'),
      		'password'=>$m->get_data('password'),
      		'status'=>$m->get_data('status'),
      		'profile'=>$m->get_data('profile'),
      		'updated_by'=>$m->get_data('updated_by'),
	  	);
	  	$q=$d->update("users_master",$a,"user_id='$user_id'");
	  	if($q>0) {
	  		if($notify=="email") {
	  			// send email for notify
				$subject = "My subject";
				$txt = "Hi $first_nameEdit,\n Your user details updated successfully on Diwagine Portal, your new password is: $Password2";
				$headers = "From: support@silverwingtechnologies.com";

				mail($email,$subject,$txt,$headers);
	  		}
	  		$_SESSION['msg']=" User updated successfully.";
	  		header("location:staff.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:staff.php");
	  	}
	  }
	}
	// Delete User

	if(isset($_POST['deleteUser'])) {
		$q=$d->delete("users_master","user_id='$user_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="User Deleted  successfully.";
	  		header("location:staff.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:staff.php");
	  	}
	}

	// Delete Student

	if(isset($_POST['deleteStudent']))
	{
		$q=$d->delete("students_master","student_id='$student_id'");
	  	if($q>0) {
	  		$_SESSION['msg']="Product Deleted  Successfully.";
	  		header("location:students.php");
	  	} else {
	  		$_SESSION['msg1']="Something Wrong";
	  		header("location:students.php");
	  	}
	}

	// update Profile
	if(isset($_POST['updateuser'])){
		$password = md5($Password2);
		// recheck password
		$p=$d->select("users_master","user_id=$user_id");
		$oldData=mysqli_fetch_array($p);
		$oPassword=$oldData['password'];
		
		if($password===$oPassword) {
		$file = $_FILES['profile']['tmp_name'];
		if(file_exists($file)) {
			$errors     = array();
		    $maxsize    = 2097152;
		    $acceptable = array(
		        // 'application/pdf',
		        'image/jpeg',
		        'image/jpg',
		        'image/gif',
		        'image/png'
		    );
		    if(($_FILES['profile']['size'] >= $maxsize) || ($_FILES["profile"]["size"] == 0)) {
		        $errors[] = 'File too large. File must be less than 2 megabytes.';
		    }

		    if(!in_array($_FILES['profile']['type'], $acceptable) && (!empty($_FILES["profile"]["type"]))) {
		        $errors[] = 'Invalid file type. Only PDF, JPG, GIF and PNG types are accepted.';
		    }
		    
		    if(count($errors) === 0) {
		    $image_Arr = $_FILES['profile'];   
	        $temp = explode(".", $_FILES["profile"]["name"]);
	        $profile = round(microtime(true)) . '.' . end($temp);
	        move_uploaded_file($_FILES["profile"]["tmp_name"], "img/" . $profile);
	    	} else {
	    		$_SESSION['msg1']='Invalid file type Or File too Large.';
		  		header("location:profile.php");
	    	}
	    } else {
	    	$profile=$old_profile_photo;
	    }
	    $m->set_data('first_nameProfile',$first_nameProfile);
	  	$m->set_data('last_name',$last_name);
	  	$m->set_data('email',$email);
	  	$m->set_data('profile',$profile);
	  	$m->set_data('updated_by',$updated_by);

	  	$a =array(
      		'first_name'=> $m->get_data('first_nameProfile'),
      		'last_name'=>$m->get_data('last_name'),
      		'email'=>$m->get_data('email'),
      		'profile'=>$m->get_data('profile'),
      		'updated_by'=>$m->get_data('updated_by'),
	  	);
	  	$q=$d->update("users_master",$a,"user_id='$user_id'");
	  	if($q>0) {
	  		$_SESSION['profile'] = $profile;
	  		$_SESSION['name'] = $first_nameProfile;
	  		$_SESSION['msg']=" Account Information successfully  Updated.";
	  		header("location:profile.php");
	  	} else {
	  		$_SESSION['msg1']="Something wrong";
	  		header("location:profile.php");
	  	}
	  } else {
	  		$_SESSION['msg1']="Your Current  Password is Wrong.";
	  		header("location:profile.php");
	  }
	}
	// Delete Session Log

	if(isset($_POST['sessionId'])) {
		$q=$d->delete("session_log","sessionId='$sessionId'");
	  	if($q>0) {
	  		$_SESSION['msg']="Session Log Deleted  Successfully.";
	  		header("location:sessionLog.php");
	  	} else {
	  		$_SESSION['msg1']="Something Wrong";
	  		header("location:sessionLog.php");
	  	}
	}
} 



// end post method 

 ?>