<?php
session_start();
  require ('dbconfig.php');
  if($_POST['signin']!= '' && $_POST['signin'] == 'Signin')
  {
    extract($_POST);
    $sql = "select * from admin_tbl where email = '".$email."' AND password = '".$password."'";
    $result = mysqli_query($con,$sql);
    $count = mysqli_num_rows($result);
    if($count > 0)
    {
      $row = mysqli_fetch_assoc($result);
      $_SESSION['email'] = $row['email'];
      $_SESSION['password'] = $row['password'];
      
      header('Location:index.php');
    }
    else
    {
      header('Location:login.php');
      //echo "Invalid Username Or Password";
    }
  }
?>