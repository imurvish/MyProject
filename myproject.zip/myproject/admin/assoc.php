<?php include'lib/dao.php';
	  include_once 'dbconfig.php';

$d = new dao();

?>

<!DOCTYPE html>
<html>
<head>
	<title> Assoc </title>
</head>
<body>
	<table border="1">
		<thead>
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Gender</th>
				<th>City</th>
				<th>Mobile</th>
			</tr>
		</thead>
		<tbody>
		

				<?php
				$i=1;
				 $q=$d->select("manage_users","","");
						while ($row=mysqli_fetch_assoc($q))
						{
							// print_r($row);
							// break;

				?>	
					<tr>
					<td><?php $i++; 
					echo $row['user_id']?></td>	
					<td><?php echo $row['name']; ?></td>
					<td><?php echo $row['email'];?></td>
					<td><?php echo $row['gender']; ?></td>
					<td><?php echo $row['city'];?></td>
					<td><?php echo $row['mobile'];?></td>

				
				
			</tr>
			<?php } ?> 
		</tbody>

	</table>

</body>
</html>