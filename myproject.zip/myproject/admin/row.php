<?php include'lib/dao.php';
	  include_once 'dbconfig.php';

$d = new dao();

?>

<!DOCTYPE html>
<html>
<head>
	<title> Row </title>
</head>
<body>
	<table border="1">
		<thead>
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Gender</th>
				<th>City</th>
				<th>Mobile</th>
			</tr>
		</thead>
		<tbody>
		

				<?php
				$i=1;
				 $q=$d->select("manage_users","","");
						while ($row=mysqli_fetch_row($q))
						{
							//printf ("%s (%s) (%s) (%s) (%s) (%s)\n",$row[0],$row[1],$row[2],$row[3],$row[4],$row[5]);
							// var_dump($row);
							// print_r($row);
							// break;
				?>
				<tr>
					<td> <?php printf("%s",$row[0]); ?></td>
					<td> <?php printf("%s",$row[1]); ?></td>
					<td> <?php printf("%s",$row[2]); ?></td>
					<td> <?php printf("%s",$row[4]); ?></td>
					<td> <?php printf("%s",$row[5]); ?></td>
					<td> <?php printf("%s",$row[6]); ?></td>
				</tr>
			<?php } ?> 
		</tbody>

	</table>

</body>
</html>