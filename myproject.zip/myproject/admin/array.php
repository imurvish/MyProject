<?php include'lib/dao.php';
	  include_once 'dbconfig.php';

$d = new dao();

?>

<!DOCTYPE html>
<html>
<head>
	<title> Array </title>
</head>
<body>
	<table border="1">
		<thead>
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Gender</th>
				<th>City</th>
				<th>Mobile</th>
			</tr>
		</thead>
		<tbody>
		

				<?php
				$i=1;
				 $q=$d->select("manage_users","","");
						while ($row=mysqli_fetch_array($q))
						{
							// print_r($row);
							// break;

				?>	
					<tr>
					<td><?php $i++; 
					echo $row[0]?></td>	
					<td><?php echo $row[1]; ?></td>
					<td><?php echo $row[2];?></td>
					<td><?php echo $row[4]; ?></td>
					<td><?php echo $row[5];?></td>
					<td><?php echo $row[6];?></td>

				
				
			</tr>
			<?php } ?> 
		</tbody>

	</table>

</body>
</html>