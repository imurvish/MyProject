<?php
session_start();

$con = mysqli_connect("localhost","root","","admin_db");
if(!$con)
	die("Not Connected To Server".mysqli_error());

$db = mysqli_select_db($con,'admin_db');
if(!$db)
	die("No Database".mysqli_error());

// echo "done";

?>