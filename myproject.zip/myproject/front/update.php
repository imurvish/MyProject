<?php 
include 'common/header.php'; 

?>
<?php 

include_once 'lib/object.php';
$id = $_SESSION['id'];
$query=$d->select('user_registration',"id=".$id);
$data=mysqli_fetch_array($query);

?>


<div class="mail" id="form-content">
	<div class="container">
		<h3>My Account</h3>
		<div class="agile_mail_grids">
			<div class="col-md-12 contact-left">
				
				<form id="update-form" method="post" name="updateform" action="controller.php" >
				<input type="hidden" name="update" value="1"> 

					<table class="table table-striped" border="2" align="center" style="background:# ">
						<tr align="center">
							<td><b>Id:</b> </td>
							<td><?php echo $data['id'];?> </td>
						</tr>
						<tr align="center">
							<td><b>Name:</b></td>
							<td> <input type="text" name="name" value="<?php echo $data['name']; ?>"></td>
							<!-- <td><?php echo $name; ?></td> -->
						</tr>
						<tr align="center">
							<td><b>E-Mail:</b></td>
							<td>
							<input type="text" name="email" value="<?php echo $data['email']; ?>">
							</td>
							<!-- <td><?php echo $email;?></td> -->
						</tr>
						<tr align="center">
							<td><b>Password:</b></td>
							<td>
							<input type="text" name="password" value="<?php echo $data['password']; ?>">
							</td>
							<!-- <td><?php echo $password; ?></td> -->
						</tr>
						<tr align="center">
							<td><b>Contact</b></td>
							<td>
								<input type="text" name="contact" value="<?php echo $data['contact']; ?>">
							</td>
							<!-- <td><?php echo $data['contact']; ?></td> -->
							<!-- <td><?php echo $contact; ?></td> -->
						</tr>
						<tr style="border: 0px;">
							<td style="border: 0px;"></td>
							<td style="border: 0px;">
							</td>		
						</tr>		
					</table>
						<input type="submit" value="Update" name="update" />
					 				
 				</form>

 			
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>

<!-- <script type="text/javascript">
$(document).ready(function() {  
    
    // submit form using $.ajax() method
    
    $('#myaccount-form').submit(function(e){
        
        e.preventDefault(); // Prevent Default Submission
        
        $.ajax({
            url: 'update.php',
            type: 'POST',
            data: $(this).serialize() // it will serialize the form data
        })
        .done(function(data){
            $('#form-content').fadeOut('slow', function(){
                $('#form-content').fadeIn('slow').html(data);
            });
        })
        .fail(function(){
            alert('Ajax Submit Failed ...');    
        });
    });
    
    
});
</script> -->
<?php include 'common/footer.php';   ?>