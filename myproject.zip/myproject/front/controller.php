<?php
error_reporting(E_ALL);
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'PhpMailer/vendor/autoload.php';

// session_start();
include'lib/object.php';

extract(array_map("test_input" , $_POST));


//---------- SELECT START----------//
    if (isset($_POST['login']))
    {
        $password=md5($_POST['password']);
        $email=$_POST['email'];
        $q=$d->select("user_registration","email='".$email."' AND password='".$password."'");
        $data=mysqli_fetch_array($q);
        // echo "<pre>";
        // print_r($data);
        // echo "</pre>";
        // die();
        // print_r($id);die();
        // $_SESSION['id']=$data['id'];
        // print_r($data);die();
        if ($data>0 )
        {
            $_SESSION['email'] = $data['email'];
            $_SESSION['id'] = $data['id'];
            header("Location:myaccount.php");
        }
        else
        {
            header("Location:index.php");
        }


    }
//---------- SELECT END----------//


//---------- INSERT START----------//
    if(isset($_POST['register']))
    {
        
        // $password = hash('sha256', $password);
        $password=md5($password);

        $m->set_data('id',$id);
        $m->set_data('name',$name);
        $m->set_data('email',$email);
        $m->set_data('password',$password);
        $m->set_data('contact',$contact);

        $a=array(
        	'id'=> test_input($m->get_data('id')),
            'name'=> test_input($m->get_data('name')),
            'email'=> test_input($m->get_data('email')),
            'password'=> test_input($m->get_data('password')),
            'contact'=> test_input($m->get_data('contact'))
            );
        // print_r($a);die();
        $q=$d->insert("user_registration",$a);

        $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
        try {
                //Server settings
                $mail->SMTPDebug = 0;                                 // Enable verbose debug output
                $mail->isSMTP();                                      // Set mailer to use SMTP
                $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
                $mail->SMTPAuth = true;                               // Enable SMTP authentication
                $mail->Username = 'bliss.urvish@gmail.com';                 // SMTP username
                $mail->Password = 'Hellourvish144   ';                           // SMTP password
                $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
                $mail->Port = 465;                                    // TCP port to connect to

                $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );

                //Recipients
                $mail->setFrom('bliss.urvish@gmail.com', 'Urvish Patel');
                $mail->addAddress($m->get_data('email'), $m->get_data('name'));     // Add a recipient
                /*$mail->addAddress('ellen@example.com');               // Name is optional
                $mail->addReplyTo('info@example.com', 'Information');
                $mail->addCC('cc@example.com');
                $mail->addBCC('bcc@example.com');*/

                //Attachments
                /*$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
                $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name*/

                //Content
                $mail->isHTML(true);                                  // Set email format to HTML
                $mail->Subject = 'No subject';
                $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
                $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                $mail->send();
                echo 'Message has been sent';
            }
            catch (Exception $e)
            {
                echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
            }

        if ($q>0)
        {        
           $_SESSION['id'] = $q;
           $_SESSION['email'] = $email;
           $_SESSION['name'] = $name;
           $_SESSION['contact'] = $contact;
           $_SESSION['msg']="Please Enter Your Password Session Is Not Store Your Password"; 
           header("Location:myaccount.php");
        }
        else
        {
            $response['status'] = 'error'; // could not register
            $response['message'] = '<span class="glyphicon glyphicon-info-sign"></span> &nbsp; could not register, try again later';
        }
    }
//---------- INSERT END----------//


//---------- UPDATE START----------//
    if(isset($_POST['update']))
    {

        $m->set_data('id',$id);
        $m->set_data('name',$name);
        $m->set_data('email',$email);
        $m->set_data('password',$password);
        $m->set_data('contact',$contact);
       
        $a=array(
            // 'id'=> test_input($m->get_data('id')),
            'name'=> test_input($m->get_data('name')),
            'email'=> test_input($m->get_data('email')),
            'password'=> test_input($m->get_data('password')),
            'contact'=> test_input($m->get_data('contact'))
            );

        $id = $_SESSION['id'];
        // print_r($id);die();
        $q=$d->update("user_registration",$a,"id=".$id);

        if($q>0) {
            $_SESSION['name'] = $name;
            $_SESSION['email'] = $email;
            $_SESSION['contact'] = $contact;
            // $_SESSION['msg']=" Menu Successfully  Updated.";
            header("location:myaccount.php");

        } else {
            $_SESSION['msg1']="Something wrong";
            // header("location:menu.php");
        }
    }
//---------- UPDATE END----------//

 ?>


