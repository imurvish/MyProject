<?php
session_start();
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';
        
        static $valid = true;
        $thanku = "0";
        if (!empty($_POST)) {
            $code    = $_POST['security_code'];
            $cptcode    = $_SESSION['security_code'];

            if (empty($code)) {
                $status  = "cerror";
                $message = "Please enter Security code";

                $valid = false;
            }else if($code !=  $cptcode ){
                $status  = "cerror";
                $message = "Please enter correct code";
                $valid = false;
            }
            else
            {
                    $bmsg="<html><head>
                            <title>Website Sales Lead</title>
                            <style>
                            .raq-head{
                    font-family: Arial, Helvetica, sans-serif;
                    font-size: 20px;
                    line-height: normal;
                    font-weight: bold;
                    color: #333333;
                    text-decoration: none;
                    border-top-width: 1px;
                    border-right-width: 1px;
                    border-bottom-width: 1px;
                    border-left-width: 1px;
                    border-top-style: solid;
                    border-right-style: solid;
                    border-bottom-style: solid;
                    border-left-style: solid;
                    border-top-color: #bcbcbc;
                    border-right-color: #bcbcbc;
                    border-bottom-color: #bcbcbc;
                    border-left-color: #bcbcbc;
                    margin: 0px;
                    padding: 0px;
                }
                .raq-head h2{
                    font-family: Arial, Helvetica, sans-serif;
                    font-size: 20px;
                    line-height: normal;
                    font-weight: bold;
                    color: #ffffff;
                    text-decoration: none;
                    margin: 0px;
                    padding: 0px;
                    }
                .myhead{
                    font-family: Arial, Helvetica, sans-serif;
                    font-size: 12px;
                    line-height: normal;
                    font-weight: bold;
                    color: #131313;
                    border-bottom-width: 1px;
                    border-bottom-style: solid;
                    border-bottom-color: #BCBCBC;
                    border-right-width: 1px;
                    border-right-style: solid;
                    border-right-color: #BCBCBC;
                    border-left-width: 1px;
                    border-left-style: solid;
                    border-left-color: #BCBCBC;
                }
                
                .myhead-right{
                    font-family: Arial, Helvetica, sans-serif;
                    font-size: 12px;
                    line-height: normal;
                    font-weight: normal;
                    color: #333333;
                    border-bottom-width: 1px;
                    border-bottom-style: solid;
                    border-bottom-color: #BCBCBC;
                    border-right-width: 1px;
                    border-right-style: solid;
                    border-right-color: #BCBCBC;
                }
                                </style>

         
            </head>
            <body topmargin='0'>
            <table width='100%'  border='0' align='center' cellpadding='0' cellspacing='0' class='bgtext'>
                <tr>
                    <td height='40'  align='center' bgcolor='#d91a24' class='raq-head'><h2 style='color:#fff;'>Website Sales Lead</h2></td>
                </tr>
                <tr>
                <tr>
                    <td><table width='100%'  border='1' align='center' cellpadding='8' cellspacing='0'  class='bgtext' >
                                        
                <tr>
                    <td width='15%' align=left bgcolor='#f6f6f6'  class='myhead' ><strong>Name:</strong></td>
                    <td align=left bgcolor='#F5F5F5' class='myhead-right'>".$_POST['name']."</td>
                </tr>
                <tr>
                    <td width='15%' align=left bgcolor='#f6f6f6'  class='myhead' ><strong>Company Name:</strong></td>
                    <td align=left bgcolor='#F5F5F5' class='myhead-right'>".$_POST['cname']."</td>
                </tr>
                 <tr>
                    <td width='15%' align=left bgcolor='#f6f6f6'  class='myhead' ><strong>Street Address:</strong></td>
                    <td align=left bgcolor='#F5F5F5' class='myhead-right'>".$_POST['saddress']."</td>
                </tr>
                 <tr>
                    <td width='15%' align=left bgcolor='#f6f6f6'  class='myhead' ><strong>City:</strong></td>
                    <td align=left bgcolor='#F5F5F5' class='myhead-right'>".$_POST['city']."</td>
                </tr>
                 <tr>
                    <td width='15%' align=left bgcolor='#f6f6f6'  class='myhead' ><strong>State:</strong></td>
                    <td align=left bgcolor='#F5F5F5' class='myhead-right'>".$_POST['state']."</td>
                </tr>
                <tr>
                    <td width='15%' align=left bgcolor='#f6f6f6'  class='myhead' ><strong>Country:</strong></td>
                    <td align=left bgcolor='#F5F5F5' class='myhead-right'>".$_POST['country']."</td>
                </tr>
                 <tr>
                    <td width='15%' align=left bgcolor='#f6f6f6'  class='myhead' ><strong>Zip Code:</strong></td>
                    <td align=left bgcolor='#F5F5F5' class='myhead-right'>".$_POST['zip']."</td>
                </tr>
                 <tr>
                    <td width='15%' align=left bgcolor='#f6f6f6'  class='myhead' ><strong>Phone:</strong></td>
                    <td align=left bgcolor='#F5F5F5' class='myhead-right'>".$_POST['phone']."</td>
                </tr>
                <tr>
                    <td align=left bgcolor='#f6f6f6' class='myhead' ><strong>Email:</strong></td>
                    <td align=left bgcolor='#F5F5F5' class='myhead-right'>".$_POST['email']."</td>
                </tr>               
                <tr>
                    <td align=left bgcolor='#f6f6f6' class='myhead' ><strong>Comments:</strong></td>
                    <td align=left bgcolor='#F5F5F5' class='myhead-right'>".$_POST['comment']."</td>
                </tr>   
                    
              </table></td></tr>
            </table>
            </body>
            </html>";

               
                


                $fromemail = "info@waltersbuildings.com";
                $to = "bliss.dhwani@gmail.com"; 
                $subject="TMS Website Sales Lead";
                $from = $_POST['email'];
                $fromname = $_POST['name'];

                $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
                try {  

                    //Recipients
                    $mail->setFrom($fromemail,'Waltersbuildings');
                    $mail->addAddress($to);     // Add a recipient 
                    $mail->addReplyTo($from,$fromname);
                    //$mail->addCC('cc@example.com');
                    //$mail->addBCC('bcc@example.com');


                    //Content
                    $mail->isHTML(true);                                  // Set email format to HTML
                    $mail->Subject = $subject;
                    $mail->Body    = $bmsg; 

                    $mail->send();
                    

                    $status  = "success";
                    $message = '';
                    $thanku = "1";

                } catch (Exception $e) {
                    $status  = "error";
                    $message = "<p>An error occurred, please try again</p>";
                    $valid = false; //echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
                } 
        }
            $data = array(
                'status'  => $status,
                'message' => $message,
                'thanku' => $thanku
            );

            echo json_encode($data);        
    }
