<?php 
session_start();
$url=$_SESSION['url'] = $_SERVER['REQUEST_URI']; 
$activePage = basename($_SERVER['PHP_SELF'], ".php");
include_once 'dao.php';
include 'model.php';
$d = new dao();
$m = new model();
extract($_POST);
extract($_GET);
 ?>