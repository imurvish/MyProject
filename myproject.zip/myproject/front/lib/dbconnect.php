<?php
class dbconnect
{
    function connect()
    {
        $connection=mysqli_connect("localhost","root","","myproject_db");
				return $connection;
    }
}
?>