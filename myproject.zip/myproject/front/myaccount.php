<?php 
include'common/header.php'; 
include_once 'lib/object.php';

$id = $_SESSION['id'];

$query=$d->select('user_registration',"id='$id'");
$data=mysqli_fetch_array($query);
// print_r($query);die();

?> 

<div class="mail">
	<div class="container">
		<h3>My Account</h3>
		<div class="agile_mail_grids">
			<div class="col-md-12 contact-left">
				<form id="myaccount-form" method="post" name="myaccountform" action="update.php">
				<input type="hidden" name="myaccount" value="1"> 

					<table class="table table-striped" border="2" align="center" style="background:# ">
						<tr align="center">
							<td><b>Id:</b> </td>
							<td><?php echo $data['id'];?> </td>
						</tr>
						<tr align="center">
							<td><b>Name:</b></td>
							<td><?php echo $data['name']; ?></td>
						</tr>
						<tr align="center">
							<td><b>E-Mail:</b></td>
							<td><?php echo $data['email'];?></td>
						</tr>
						<tr align="center">
							<td><b>Password:</b></td>
							<td><?php echo $data['password']; ?></td>
						</tr>
						<tr align="center">
							<td><b>Contact</b></td>
							<td><?php echo $data['contact']; ?></td>
						</tr>
						<tr style="border: 0px;">
							<td style="border: 0px;"></td>
							<td style="border: 0px;">
								<input type="submit" value="Edit"/>
							</td>		
						</tr>		
					</table>
 				</form>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>

<?php include'common/footer.php'; ?>